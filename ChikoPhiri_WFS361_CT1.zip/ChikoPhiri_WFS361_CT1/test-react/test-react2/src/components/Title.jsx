import React from 'react'

function Title() {
  return (
    <div>
      <article className='Title1'>
        <h3>What i do</h3>
      </article>
    </div>
  )
}

export default Title
