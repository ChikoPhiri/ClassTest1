import React from 'react'
import image3 from '../components/Assests/pic-3.PNG';

function Article3() {
  return (
    <div>
      <section>
        <img src={image3} alt=""/>
      
        <p>
      
        <h10>Marketing</h10>
        <br></br>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, enim obcaecati. Voluptatem quis ad, reiciendis in praesentium sit labore dolores nobis
          molestiae magnam neque nemo ducimus, 
          magni nam culpa non?
          <br></br>
          <h2> read more</h2>
        </p>
        </section>
    </div>
  )
}

export default Article3
