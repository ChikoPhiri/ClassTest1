import React from 'react'
import image1 from '../components/Assests/pic-1.PNG'
import image2 from '../components/Assests/pic-2.PNG'
import image3 from '../components/Assests/pic-3.PNG'

function Content() {
  return (
    <div>
      
      <section>

      <section>
        <img src={image1} alt="pic1"/>
      
        <p className='column1'>
      
        <h5>graph design</h5>
        <br></br>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, enim obcaecati. Voluptatem quis ad, reiciendis in praesentium sit labore dolores nobis
        
          <br></br>
          <h2> read more</h2>
        </p>
        </section>
        
        <img src={image2} alt="pic2"/>
        <p className='column2'>
        
        <h5>web development</h5>
        <br></br>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, enim obcaecati. Voluptatem quis ad, reiciendis in praesentium sit labore dolores nobis
       
          <br></br>
          <h2> read more</h2>
        </p>
     
        <img src={image3} alt="pic3"/>
        <section>
    
      
        <p className='column3'>
      
        <h5>Marketing</h5>
        <br></br>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, enim obcaecati. Voluptatem quis ad, reiciendis in praesentium sit labore dolores nobis
          molestiae magnam 
          <br></br>
          <h2> read more</h2>
        </p>
        </section>
        </section>
      
    </div>
  )
}

export default Content
