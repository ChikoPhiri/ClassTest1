import React from 'react'

function Subtitle() {
  return (
    <div>
        <article id="class2">
         Praesentium inventore necessitatibus ex iste obcaecati alias impedit magni veritatis! Nobis nisi error pariatur r
          umquam?
        </article>
      
    </div>
  )
}

export default Subtitle
