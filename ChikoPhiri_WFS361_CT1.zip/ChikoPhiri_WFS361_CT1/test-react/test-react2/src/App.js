
import './App.css';
import Title from'../src/components/Title.jsx';
import Subtile from '../src/components/Subtitle.jsx';
import Content from '../src/components/Content.jsx';

function App() {
  return (
    <div >
   
    <Title/>
    <Subtile/>
    <Content/>

    </div>
  );
}

export default App;
